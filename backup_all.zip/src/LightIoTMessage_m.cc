// /src/LightIoTMessage_m.cc

#include "LightIoTMessage_m.h"